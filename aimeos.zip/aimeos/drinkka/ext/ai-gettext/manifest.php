<?php

return array(
	'name' => 'ai-gettext',
	'depends' => array(
		'aimeos-core',
	),
	'include' => array(
		'lib/custom/src',
	),
);
