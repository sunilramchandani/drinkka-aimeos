<?php

return [
	'fs' => [
		'adapter' => 'Standard',
		'basedir' => 'tmp',
	],
	'fs-import' => [
		'adapter' => 'Standard',
		'basedir' => 'tmp/import',
	],
];